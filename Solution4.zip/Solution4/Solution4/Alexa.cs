﻿using System;

namespace Solution4
{
    internal class Alexa
    {
        public Alexa()
        {
        }

        public string Talk()
        {
            return "I am alexa";
        }

        internal void Configure(Func<object, object> p)
        {
            throw new NotImplementedException();
        }
    }
}