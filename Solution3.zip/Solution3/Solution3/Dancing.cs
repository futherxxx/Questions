﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Solution3
{
    public class Dancing : ISkills
    {

        public Dancing()
        {
            
        }
    }
}
