﻿namespace Solution3
{
    public class Cooking : ISkills
    {
        public Cooking()
        {
            
        }
    }
}