﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Solution3
{
    public class Humanoid 
    {

        public string response = "";
        public Humanoid()
        {
            response = "No Skills defined";
        }

        public Humanoid(ISkills skills)
        {
            if(skills.GetType()==typeof(Dancing))
            {
              response="Dancing";
            }
            else if (skills.GetType() == typeof(Cooking))
            {
               response="Cooking";
            }
            else
            {
                response="No skill defined";
            }
        }


        public string ShowSkill()
        {
            return response;
        }
    }
}
