﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Solution5
{
     class Program
    {
        private static void  Main(string[] args)
        {
            EmployeeResult empResultCalculation = new EmployeeResult();
            empResultCalculation.PerfomCalculation();
            Console.ReadKey();
        }

      
    }
}
