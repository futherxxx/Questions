﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Solution5
{
    class CalculationUtil
    {
        public async void Calculate()
        {
           // var (averageSalary, numberOfEmployee) = await SomeCalculation(0L, 10L, 0L == 10L);
        }

      
    }

  
}
