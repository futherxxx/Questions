﻿using System;
using System.Threading.Tasks;

namespace Solution5
{
    public class EmployeeResult
    {
        public int averageSalary { get; set; }
        public int numberOfEmployee { get; set; }

        public EmployeeResult()
        {

        }

        public async void PerfomCalculation()
        {
            var employeeResult = await SomeCalculation(0L, 10L, 0L == 10L);
        }

        private async Task<EmployeeResult> SomeCalculation(long v1, long v2, bool v3)
        {
            EmployeeResult employeeResultCalculation = new EmployeeResult();
            //Do Some calculation
            Console.WriteLine("Calculation performed....");
            return await Task.FromResult(employeeResultCalculation);
        }
    }
}