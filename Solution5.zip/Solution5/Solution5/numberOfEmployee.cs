﻿namespace Solution5
{
    internal class numberOfEmployee
    {
    }
}