﻿using System;
using System.Collections.Generic;

namespace Solution2
{
    public class User
    {
        public static User userInstance = new User();
        public  string[] _users;


        public User()
        {
            
            
        }





        public void Add(string userName)
        {
            try
            {
                if (userInstance._users == null)
                {
                    userInstance._users = new string[0];
                }
                else
                {
                    int arrayLength = userInstance._users.Length;
                    string[] userClone = new string[arrayLength];
                    userInstance._users.CopyTo(userClone, 0);

                    userInstance._users = new string[arrayLength + 1];

                    for (int i = 0; i < arrayLength; i++)
                    {
                        userInstance._users[i] = userClone[i];
                    }
                    userInstance._users[arrayLength + 1] = userName;
                }
            }
            catch (Exception)
            {

                
            }

           
        }

        public  int GetUsersCount()
        {
           return userInstance._users.Length;
        }
    }
}