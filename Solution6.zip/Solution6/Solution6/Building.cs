﻿using System;

namespace Solution6
{
    public class Building
    {

        public string buildconfiguration;
        public Building AddKitchen()
        {
            this.buildconfiguration += " kitchen ";
            return this;
        }

        public Building AddBedroom(string room)
        {
            this.buildconfiguration += string.Format(" {0}",room);
            return this;
        }

        public Building AddBalcony()
        {
            this.buildconfiguration += " balcony";
            return this;
        }

        public void Build()
        {
            Console.WriteLine(this.buildconfiguration);
        }

        public string Describe()
        {
            return this.buildconfiguration;
        }
    }
}